
import pandas as pd
import numpy as np
from collections import Counter
from sklearn.model_selection import train_test_split

def calculate_distance(p1, p2):
    return np.linalg.norm(np.array(p1) - np.array(p2))

def knn_predict(train_data, train_labels, test_data, k=3):
    predictions = []
    for test_point in test_data:
        distances = [(calculate_distance(train_point, test_point), label) for train_point, label in zip(train_data, train_labels)]
        distances.sort(key=lambda x: x[0])
        k_nearest_labels = [label for _, label in distances[:k]]
        predictions.append(Counter(k_nearest_labels).most_common(1)[0][0])
    return predictions

df = pd.read_csv('knn.csv')
features = df.iloc[:, :-1].values
labels = df.iloc[:, -1].values
train_features, test_features, train_labels, test_labels = train_test_split(features, labels, test_size=0.2, random_state=0)
predictions = knn_predict(train_features, train_labels, test_features, k=3)
print("Predictions:", predictions)
print("Actual Labels:", test_labels.tolist())
