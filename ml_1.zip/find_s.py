
import pandas as pd

def find_s(concepts, target):
    hypothesis = ['?' for _ in range(len(concepts.columns))]
    for i, row in concepts.iterrows():
        if target[i] == "Yes":  # Assuming binary classification with 'Yes' as positive
            for j in range(len(hypothesis)):
                if hypothesis[j] == '?':
                    hypothesis[j] = row[j]
                elif hypothesis[j] != row[j]:
                    hypothesis[j] = '?'
    return hypothesis

# Load data
df = pd.read_csv('find_s.csv')
concepts = df.iloc[:, :-1]  # Features
target = df.iloc[:, -1]  # Target class

hypothesis = find_s(concepts, target)
print("Final Hypothesis:", hypothesis)
