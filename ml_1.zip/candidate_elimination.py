
import pandas as pd

def candidate_elimination(concepts, target):
    specific_h = ['?' for _ in range(len(concepts.columns))]
    general_h = [['?' for _ in range(len(concepts.columns))] for _ in range(len(concepts.columns))]

    for i, row in concepts.iterrows():
        if target[i] == "Yes":
            for j in range(len(specific_h)):
                if specific_h[j] == '?':
                    specific_h[j] = row[j]
                elif specific_h[j] != row[j]:
                    specific_h[j] = '?'
            general_h = [g for g in general_h if any(g[j] == '?' or g[j] == row[j] for j in range(len(row)))]
        else:
            for j in range(len(row)):
                if specific_h[j] != row[j] and specific_h[j] != '?':
                    general_h[j][j] = specific_h[j]

    return specific_h, [g for g in general_h if g != ['?' for _ in range(len(row))]]

# Load data
df = pd.read_csv('candidate_elimination.csv')
concepts = df.iloc[:, :-1]
target = df.iloc[:, -1]

specific, general = candidate_elimination(concepts, target)
print("Specific Hypothesis:", specific)
print("General Hypotheses:", general)
