
import pandas as pd
import numpy as np

def calculate_distance(point1, point2):
    return np.linalg.norm(np.array(point1) - np.array(point2))

def kmeans(X, k, max_iters=100):
    centroids = X[np.random.choice(X.shape[0], k, replace=False)]
    for _ in range(max_iters):
        labels = np.array([np.argmin([calculate_distance(x, centroid) for centroid in centroids]) for x in X])
        new_centroids = np.array([X[labels == i].mean(axis=0) for i in range(k)])
        if np.all(new_centroids == centroids):
            break
        centroids = new_centroids
    return centroids, labels

df = pd.read_csv('kmeans.csv')
X = df.values
centroids, labels = kmeans(X, k=3)
print("Centroids:", centroids)
print("Labels:", labels)
