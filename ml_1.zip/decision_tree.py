
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split

df = pd.read_csv('decision_tree.csv')
X = df.iloc[:, :-1].values
y = df.iloc[:, -1].values

train_X, test_X, train_y, test_y = train_test_split(X, y, test_size=0.2, random_state=0)
model = DecisionTreeClassifier()
model.fit(train_X, train_y)

predictions = model.predict(test_X)
print("Predictions:", predictions)
print("Actual values:", test_y)
