
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

df = pd.read_csv('linear_regression.csv')
X = df.iloc[:, :-1].values
y = df.iloc[:, -1].values

train_X, test_X, train_y, test_y = train_test_split(X, y, test_size=0.2, random_state=0)
model = LinearRegression()
model.fit(train_X, train_y)

predictions = model.predict(test_X)
print("Predictions:", predictions)
print("Actual values:", test_y)
