#include<iostream>                                                                                                                          
#include<cstring>                                                                                                                           
#include<arpa/inet.h>                                                                                                                       
#include<unistd.h>                                                                                                                          
#define port 3544                                                                                                                           
using namespace std;                                                                                                                        
int main(){                                                                                                                                 
        int sockdesc;                                                                                                                       
        struct sockaddr_in servaddr;                                                                                                        
        sockdesc=socket(AF_INET,SOCK_STREAM,0);                                                                                             
        if(sockdesc<=0){                                                                                                                    
                cout<<"socket Failed";                                                                                                      
                return 1;                                                                                                                   
        }                                                                                                                                   
        servaddr.sin_family=AF_INET;                                                                                                        
        servaddr.sin_port=htons(port);                                                                                                      
        servaddr.sin_addr.s_addr=INADDR_ANY;                                                                                                
        if(connect(sockdesc,(struct sockaddr*)&servaddr,sizeof(servaddr))<0){                                                               
                cout<<"connection Failed";  
                exit(1);                                                                                                
        }        
        while(true){                                                                                                                           
        char buffer[100]={0};                                                                                                               
        //string res(buffer);                                                                                                               
        cout<<"enter string :";                                                                                                               
        cin>>buffer;   
        if(strcmp(buffer,"exit")==0) {
            break;
        }                                                                                                                     
        send(sockdesc,buffer,sizeof(buffer),0);                                                                                             
        // cout<<"msg sent"<<endl;                                                                                                             
        recv(sockdesc,buffer,sizeof(buffer),0);                                                                                             
        cout<<"msg from server:"<<buffer<<endl;   
        }                                                                                          
        close(sockdesc);                                                                                                                    
}