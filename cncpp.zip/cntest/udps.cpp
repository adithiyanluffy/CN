#include<iostream>
#include<cstring>
#include<arpa/inet.h>
#include<unistd.h>
using namespace std;
#define port 3519
int main(){
    int sockdesc;
    struct sockaddr_in servaddr;
    sockdesc=socket(AF_INET,SOCK_DGRAM,0);
    if(sockdesc <0){
        cout<<"socket creation failed";
    }
    servaddr.sin_family=AF_INET;
    servaddr.sin_port=htons(port);
    servaddr.sin_addr.s_addr=INADDR_ANY;
    if(bind(sockdesc,(struct sockaddr*)&servaddr,sizeof(servaddr))<0){
        cout<<"bind Failed";
        exit(1);
    }
    int size=sizeof(servaddr);
    while(1){
        char buffer[50];
        int n=recvfrom(sockdesc,buffer,sizeof(buffer),0,(struct sockaddr*)&servaddr,(socklen_t*)&size);
        if(n<=0){
            cout<<"no msg recvd"<<endl;
            break;
        }
        else cout<<"msg :"<<buffer<<endl;
        sendto(sockdesc,buffer,sizeof(buffer),0,(struct sockaddr*)&servaddr,size);
        cout<<"msg sent to client";
        
    }
    close(sockdesc);
    }