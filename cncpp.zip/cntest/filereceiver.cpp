#include <iostream>
#include <fstream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define PORT 3519
#define PACKET_SIZE 1024

int main() {
    int sockfd;
    struct sockaddr_in serverAddr, clientAddr;
    socklen_t addrLen = sizeof(clientAddr);
    char buffer[PACKET_SIZE];
    ssize_t bytesReceived;

    // Create a UDP socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        std::cerr << "Socket creation failed!" << std::endl;
        return 1;
    }

    // Configure server address
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_addr.s_addr = INADDR_ANY;
    serverAddr.sin_port = htons(PORT);

    // Bind the socket to the port
    if (bind(sockfd, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) < 0) {
        std::cerr << "Binding failed!" << std::endl;
        close(sockfd);
        return 1;
    }

    std::cout << "UDP Server is listening on port " << PORT << std::endl;

    std::ofstream outputFile("receivedFile.txt", std::ios::binary);
    if (!outputFile.is_open()) {
        std::cerr << "Failed to open output file!" << std::endl;
        close(sockfd);
        return 1;
    }

    while (true) {
        // Receive data from the client
        bytesReceived = recvfrom(sockfd, buffer, PACKET_SIZE, 0, (struct sockaddr*)&clientAddr, &addrLen);
        if (bytesReceived < 0) {
            std::cerr << "Error receiving data!" << std::endl;
            break;
        }
        
        if (bytesReceived == 0) {
            std::cout << "File transfer completed." << std::endl;
            break; // End of file transmission
        }

        // Write received data to the file
        outputFile.write(buffer, bytesReceived);
        std::cout << "Received " << bytesReceived << " bytes." << std::endl;
    }

    outputFile.close();
    close(sockfd);
    std::cout << "File received and saved as 'received_file.txt'." << std::endl;

    return 0;
}
