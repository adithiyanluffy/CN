#include<iostream>                                                                                                                          
#include<arpa/inet.h>                                                                                                                       
#include<unistd.h>                                                                                                                          
#include<cstring>                                                                                                                           
#include<string>                                                                                                                            
#define PORT 3544                                                                                                                        
                                                                                                                                            
int main(){                                                                                                                                 
        int sockdesc;                                                                                                                       
        struct sockaddr_in servaddr;                                                                                                        
                                                                                                                                            
        sockdesc=socket(AF_INET,SOCK_STREAM,0);                                                                                             
        if(sockdesc<=0){                                                                                                                    
                std::cout<<"socket failed";                                                                                                 
        }                                                                                                                                   
        servaddr.sin_family=AF_INET;                                                                                                        
        servaddr.sin_port=htons(PORT);                                                                                                      
        servaddr.sin_addr.s_addr=INADDR_ANY;                                                                                                
        if(bind(sockdesc,(struct sockaddr*)&servaddr,sizeof(servaddr))<0){                                                                  
                std:: cout<<"bind failed";                                                                                                  
        }                                                                                                                                   
        if(listen(sockdesc,5)<0)                                                                                                            
                std::cout<<"listen failed";                                                                                                 
        int connfd;                                                                                                                         
        int size=sizeof(servaddr);                                                                                                          
        connfd=accept(sockdesc,(struct sockaddr*)&servaddr,(socklen_t*)&size);                                                              
        if(connfd<0){                                                                                                                       
                std:: cout<<"accept Failed";                                                                                                
        }         
        while(true){                                                                                                                                 
        char buffer[100]={0};                                                                                                                                                                                                                    
        int bytes_read=read(connfd,buffer,sizeof(buffer));                                                                                         
if(bytes_read==0){
    std::cout<<"breaked";
    break;
}                                                                                                  
        std::string res;                                                                                                            
        std::cout<<"received:"<<buffer<<std::endl;                                                                                             
       std:: cout<<"eneter msg :";
        std::cin>>res;                                                                                                          
        send(connfd,res.c_str(),res.size(),0); 
}                                                                                             
                        close(sockdesc);                                                                                                    
                        }                                                                                                                   
                                   