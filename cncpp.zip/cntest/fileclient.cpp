#include <iostream>
#include <fstream>
#include <cstring>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define PORT 3519
#define PACKET_SIZE 1024

int main() {
    int sockfd;
    struct sockaddr_in serverAddr;
    char buffer[PACKET_SIZE];

    // Create a UDP socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        std::cerr << "Socket creation failed!" << std::endl;
        return 1;
    }

    // Configure server address
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(PORT);
    if (inet_pton(AF_INET, "127.0.0.1", &serverAddr.sin_addr) <= 0) {
        std::cerr << "Invalid address!" << std::endl;
        return 1;
    }

    // Open the file for reading
    std::ifstream file("example.txt", std::ios::binary);
    if (!file.is_open()) {
        std::cerr << "File not found!" << std::endl;
        close(sockfd);
        return 1;
    }

    // Read the file in chunks and send it
    while (!file.eof()) {
        file.read(buffer, PACKET_SIZE);
        ssize_t bytesRead = file.gcount(); // Number of bytes read

        if (bytesRead > 0) {
            ssize_t bytesSent = sendto(sockfd, buffer, bytesRead, 0, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
            if (bytesSent < 0) {
                std::cerr << "Error sending data!" << std::endl;
                break;
            }

            std::cout << "Sent " << bytesSent << " bytes." << std::endl;
        }
    }

    // Send a termination packet (0 bytes) to signal the end of the file
    sendto(sockfd, "", 0, 0, (struct sockaddr*)&serverAddr, sizeof(serverAddr));

    file.close();
    close(sockfd);

    std::cout << "File sent successfully." << std::endl;

    return 0;
}
