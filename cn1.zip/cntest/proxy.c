#include "myheader.h"                                                                                                          
#include<stdlib.h>                                                                                                             
int main(int argc, char *argv[]){                                                                                              
        response sr;                                                                                                           
        strcpy(sr.version, "http/1.1");                                                                                        
        strcpy(sr.connection, "keep-alive");                                                                                   
        strcpy(sr.contype, "text");                                                                                            
        struct sockaddr_in serveraddr;                                                                                         
        int serfd;                                                                                                             
        int sockfd = socket(AF_INET, SOCK_STREAM, 0);                                                                          
        struct sockaddr_in newaddr;                                                                                            
        serfd = socket(AF_INET, SOCK_STREAM, 0);                                                                               
        if(serfd == -1){                                                                                                       
                printf("\nSocket creation failed with origin server");                                                         
                exit(0);                                                                                                       
        }                                                                                                                      
        printf("\nConnected with origin server\n");                                                                            
        newaddr.sin_family = AF_INET;                                                                                          
        newaddr.sin_addr.s_addr = inet_addr("127.0.0.1");                                                                      
        newaddr.sin_port = htons(PORT);                                                                                        
        if(connect(serfd, (struct sockaddr *)&newaddr, sizeof(newaddr)) != 0){                                                 
                printf("\nConnection failed with origin server");                                                              
                exit(0);                                                                                                       
        }                                                                                                                      
        serveraddr.sin_family = AF_INET;                                                                                       
        serveraddr.sin_port = htons(7022);                                                                                     
         serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);                                                                       
        if (bind(sockfd, (struct sockaddr *) &serveraddr,                                                                      
                                 sizeof(serveraddr)) < 0) return 0;                                                            

        if (listen(sockfd, 2) < 0) return 0;                                                                                   
         printf("Server listening on port: %d\n", 7022);                                                                       

        int clisock = accept(sockfd, NULL, NULL);                                                                              
        if (clisock < 0) return 0;                                                                                             

        clock_t c1, c2;                                                                                                        
        while(1){                                                                                                              

                request clr;                                                                                                   
                if(clisock < 0) return 0;                                                                                      
                int len = recv(clisock, &clr, sizeof(clr), 0);                                                                 
                c1 = clock();                                                                                                  
                printf("\nCLIENT'S REQUEST:\n%s%s%s\nConnection: %s\nAccept:%s\nUser-Agent: %s\nRegno: %d\nRequired sem: %d\n\n
",                                                                                                                             
                                clr.method, clr.path, clr.version,                                                             

                                clr.connection, clr.accept, clr.useragent, clr.stu.regno, clr.stu.sem);                        

                if (clr.stu.sem == -1) break;                                                                                  

                FILE *inf;                                                                                                     

                inf = fopen("cache.txt", "rb");                                                                                

                student s;                                                                                                     

                int found = 0;                                                                                                 

                while(fread(&s, sizeof(student), 1, inf) == 1){                                                                

                        if (s.regno == clr.stu.regno && s.sem ==                                                               

                                        clr.stu.sem) {                                                                         

                                found = 1;                                                                                     
                                printf("\nCACHE HIT\n");                                                                       
                                sr.stu = s;                                                                                    

                                strcpy(sr.statmsg, " Cache Hit");                                                              

                                sr.status = 200;                                                                               

                                break;                                                                                         

                        }                                                                                                      

                } if (!found){                                                                                                 
                        printf("\nCACHE MISS\n");                                                                              
                        send(serfd, &clr, sizeof(clr), 0);                                                                     
                        recv(serfd, &sr, sizeof(sr), 0);                                                                       
                        if(sr.status == 200){                                                                                  
                                FILE *fp;                                                                                      
                                fp = fopen("cache.txt","a");
                                fwrite(&(sr.stu), sizeof(sr.stu),1, fp);                                                       
                                fclose(fp);                                                                                    
                        }                                                                                                      
                        bzero(&clr, sizeof(clr));                                                                              
                }                                                                                                              

                fclose(inf);                                                                                                   
                c2 = clock();                                                                                                  
                send(clisock, &sr, sizeof(sr), 0);                                                                             
                printf("\nTime taken : %d\n",c2 - c1);                                                                         
        }                                                                                                                      

        close(serfd);                                                                                                          
        close(sockfd);                                                                                                         

        return 0;                                                                                                              

}
