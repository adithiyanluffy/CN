#include<stdio.h>                                                                                                              
#include<string.h>                                                                                                             
#include<arpa/inet.h>                                                                                                          
#include<sys/socket.h>                                                                                                         
#include<sys/types.h>                                                                                                          
#include<unistd.h>                                                                                                             
                                                                                                                               
#define PORT 63524                                                                                                             
void main(){                                                                                                                   
        struct sockaddr_in servaddr,cliaddr;                                                                                   
        int servfd, clifd;                                                                                                     
        if((servfd = socket(AF_INET, SOCK_STREAM, 0)) != 0){                                                                   
                printf("\nFailed Socket Connetion");                                                                           
                exit(0);                                                                                                       
        }                                                                                                                      
                                                                                                                               
        servaddr.sin_family = AF_INET;                                                                                         
        servaddr.sin_addr.s_addr = INADDR_ANY;                                                                                 
        servaddr.sin_port = htons(PORT);                                                                                       
                                                                                                                               
        if(bind(servfd,(struct sockaddr *)&servaddr,sizeof(servaddr)) != 0){                                                   
                printf("Bind failed");                                                                                         
                close(servfd);                                                                                                 
                exit(0);                                                                                                       
        }                                                                                                                      
                                                                                                                               
        if(listen(servfd, 0) != 0){                                                                                            
                printf("Bind failed");                                                                                         
                close(servfd);                                                                                                 
                exit(0);                                                                                                       
        }                                                                                                                      
                                                                                                                               
        int len = sizeof(cliaddr);                                                                                             
                                                                                                                               
        if((accept(clifd, (struct sockaddr *)&cliaddr,&len)) ! = 0){                                                           
                printf("Bind failed");                                                                                         
                close(servfd);                                                                                                 
                exit(0);                                                                                                       
        }                                                                                                                      
                                                                                                                               
        char buff[1024];                                                                                                       
        while(1){                                                                                                              
                bzero(buff,1024);                                                                                              
                recv(clifd, buff, 1024, 0);                                                                                    
                if(strncmp(buff,"exit",4) == 0){                                                                               
                        break;                                                                                                 
                }                                                                                                              
                printf("From Client : %s", buff);                                                                              
                bzero(buff,1024);                                                                                              
                printf("Enter String: ");                                                                                      
                scanf("%[^\n]s",buff);                                                                                         
                send(clifd,buff,1024,0);                                                                                       
        }                                                                                                                      
        close(servfd);                                                                                                         
        close(clifd);                                                                                                          
} 
