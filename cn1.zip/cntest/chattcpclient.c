#include<stdio.h>                                                                                                              
#include<string.h>                                                                                                             
#include<stdlib.h>                                                                                                             
#include<arpa/inet.h>                                                                                                          
#include<sys/socket.h>                                                                                                         
#include<sys/types.h>                                                                                                          
#include<unistd.h>                                                                                                             
                                                                                                                               
#define PORT 63524                                                                                                             
void main(){                                                                                                                   
        int sockfd;                                                                                                            
        struct sockaddr_in servaddr;                                                                                           
                                                                                                                               
        if((sockfd = socket(AF_INET, SOCK_STREAM, 0))!= 0){                                                                    
                printf("\nSocket Connection Failed");                                                                          
                exit(0);                                                                                                       
        }                                                                                                                      
                                                                                                                               
        servaddr.sin_family = AF_INET;                                                                                         
        servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");                                                                     
        servaddr.sin_port = htons(PORT);                                                                                       
                                                                                                                               
        if(connect(sockfd,(struct sockaddr*)&servaddr,sizeof(servaddr))!=0){                                                   
                printf("\nConnection Failed");                                                                                 
                exit(0);                                                                                                       
        }                                                                                                                      
        char buff[1024];                                                                                                       
        while(1){                                                                                                              
                bzero(buff,1024);                                                                                              
                printf("\nEnter Message:\n");                                                                                  
                scanf("%[^\n]s",buff);                                                                                         
                send(sockfd,buff,sizeof(buff),0);                                                                              
                bzero()                                                                                                        
        }                                                                                                                      
} 
